export interface Home {
    id: string;
    title: string;
    imageUrl: string[];
    harga: string;
    stok: number;
    merek: string;
    model: string;
    base_clock: string;
    boost_clock: string;
    jumlah_core: string;
    thread: string;
    speed:string;
    ukuran:string;
    chipset:string;
    ditujukanuntukprosesorapa:string;

}