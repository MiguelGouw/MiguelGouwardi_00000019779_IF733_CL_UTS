import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Home } from './home.model';

@Injectable({
  providedIn: 'root'
})
export class HomeService {
  productHaveStock = [];
  private homes : Home[] = 
  [
    {
      //Processor
      id : 'r1',
      title: 'Intel Core-i7',
      imageUrl: 'https://c1.neweggimages.com/ProductImage/19-115-224-03.jpg',
      harga:'1.5000.000',
      stok:100,
      merek: 'Intel',
      model: 'Ada',
      base_clock: 'ada',
      boost_clock: 'ada',
      jumlah_core: 'ada',
      thread: 'ada',
      speed:null,
      ukuran:null,
      chipset:null,
      ditujukanuntukprosesorapa:null
    },
    {
      id : 'r2',
      title: 'Vgen 10600',
      imageUrl: 'https://lh3.googleusercontent.com/proxy/e_vh0e3pgpbuaVvoyuecR1t1vePQSYIh44H9WFkog2vPdj93IJBCWEqm9MKHgfylk4nT0P4yaJW8SixPXYDiI_TUnMSdqpf3wnrCWnp6IUBVUH_yLQvAdi10cwxWZs0ylhilkPtB_moq9EGMd2xcjdfHxrliCyyU',
      harga:'405.000',
      stok:10,
      merek: 'Intel',
      model: 'ada',
      base_clock: null,
      boost_clock: null,
      jumlah_core: null,
      thread: null,
      speed:'ada',
      ukuran:'ada',
      chipset:null,
      ditujukanuntukprosesorapa:null
    },
    {
      id : 'r3',
      title: 'Asus Rog Strix Z490-E Gamming',
      imageUrl: 'https://c1.neweggimages.com/ProductImage/13-119-268-V01.jpg',
      harga:'2.560.000',
      stok:20,
      merek: 'Intel',
      model: 'ada',
      base_clock: null,
      boost_clock: null,
      jumlah_core: null,
      thread: null,
      speed:null,
      ukuran:null,
      chipset:'ada',
      ditujukanuntukprosesorapa:'ada'
    },
    {
      id : 'r4',
      title: 'Nvidia GeForce RTX 3080',
      imageUrl: 'https://cdn.mos.cms.futurecdn.net/obNHUnF85G2kHtApYvix5D.png',
      harga:'15.900.000',
      stok:40,
      merek: 'Intel',
      model: 'ada',
      base_clock: null,
      boost_clock: null,
      jumlah_core: null,
      thread: null,
      speed:null,
      ukuran:null,
      chipset:null,
      ditujukanuntukprosesorapa:null
    },
  ];
  constructor() { }

  
  getAllHomes(){
    this.productHaveStock = [];
    let j = 0;
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0 ; i < this.homes.length; i++){
      if (this.homes[i].stok > 0){
        this.productHaveStock[j] = this.homes[i];
        j++;
      }
    }
    return [...this.productHaveStock];
  }

  // getAllHomes(){
  //   return[...this.homes];
  // }

  getHome(homeId: string){
    return{...this.homes.find(home=>{return home.id === homeId;
    })};
  }
  deleteHome(homeId: string){
    this.homes = this.homes.filter(home=>{
      return home.id !== homeId;
    });
  }
  addProduct(data: FormGroup){
    let DATA = {
      id: 'r' + (parseInt(this.homes[this.homes.length-1].id.substring(1))+1).toString(),
      title : data.value.title,
      imageUrl:data.value.imageUrl,
      merek: data.value.merek,
      model: data.value.model,
      harga: data.value.harga,
      stok: data.value.stok,
      base_clock: data.value.base_clock,
      boost_clock: data.value.boost_clock,
      jumlah_core: data.value.jumlah_core,
      thread: data.value.thread,
      speed: data.value.speed,
      ukuran: data.value.ukuran,
      chipset: data.value.chipset,
      ditujukanuntukprosesorapa: data.value.ditujukanuntukprosesorapa,
    }
    this.homes.push(DATA);
  }
}