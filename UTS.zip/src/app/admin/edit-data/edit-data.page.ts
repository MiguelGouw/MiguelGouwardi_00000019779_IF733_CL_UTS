import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-data',
  templateUrl: './edit-data.page.html',
  styleUrls: ['./edit-data.page.scss'],
})
export class EditDataPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
